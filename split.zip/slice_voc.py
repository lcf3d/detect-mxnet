import argparse
import queue
import cv2
import numpy as np
from tqdm import tqdm
from typing import List
from pathlib import Path
from multiprocessing import Pool, Manager
from data import Object
from data.voc import mkdir_voc_or_clean
from data.voc import Annotation


def parse_args():
    parser = argparse.ArgumentParser(description="将VOC格式的大图数据集划分小图")
    parser.add_argument("--src", type=str, default="./VOC2007", help="大图所在根目录")
    parser.add_argument("--dst", type=str, default="./VOC2007_small", help="导出目录")
    parser.add_argument("--shape", type=int, default=320, help="小图尺寸")
    parser.add_argument("--overlap", type=float, default=0.15, help="重叠比例")
    parser.add_argument("--num-workers", type=int, default=4, help="进程数")
    return parser.parse_args()


def process(
        q: queue.Queue, result_keys: List[tuple],
        h: int, w: int, slice_h: int, slice_w: int, dy: int, dx: int,
        objects: List[Object]
) -> None:
    result = {}
    mask_tmpl = np.zeros((h, w))
    for key in result_keys:
        result[key] = []
    for i, obj in enumerate(tqdm(objects)):
        mask = mask_tmpl.copy()
        mask[obj.y_min:obj.y_max, obj.x_min:obj.x_max] = 1
        col_flag = 0
        for y in range(0, h, dy):
            if col_flag == 2:
                break
            row_flag = 0
            for x in range(0, w, dx):
                if row_flag == 2:
                    break
                y0 = y if y + slice_h <= h else h - slice_h
                x0 = x if x + slice_w <= w else w - slice_w
                part = mask[y0:y0 + slice_h, x0:x0 + slice_w]
                ys, xs = np.where(part == 1)
                if ys.size == 0 or xs.size == 0:
                    if row_flag == 1:
                        row_flag = 2
                    continue
                result[(y0, x0)].append(Object(obj.name, xs[0], ys[0], xs[-1], ys[-1]))
                if row_flag == 0:
                    row_flag = 1
            if col_flag == 0 and row_flag == 2:
                col_flag = 1
            if col_flag == 1 and row_flag == 0:
                col_flag = 2
    q.put(result)


if __name__ == '__main__':
    args = parse_args()
    src_path, dst_path = Path(args.src).absolute(), Path(args.dst).absolute()

    if not src_path.exists():
        raise RuntimeError("指定大图目录不存在")
    mkdir_voc_or_clean(dst_path)

    src_img_path, src_label_path = src_path / "JPEGImages", src_path / "Annotations"
    dst_img_path, dst_label_path = dst_path / "JPEGImages", dst_path / "Annotations"

    slice_dy = slice_dx = int((1 - args.overlap) * args.shape)

    manager = Manager()

    for label_path in src_label_path.glob("*.xml"):
        queue = manager.Queue()
        pool = Pool(processes=args.num_workers)
        print(f"正在处理 {label_path.stem}")
        file_name = label_path.stem
        a = Annotation.from_xml(str(label_path))
        result = {}
        for y in range(0, a.height, slice_dy):
            for x in range(0, a.width, slice_dx):
                y0 = y if y + args.shape <= a.height else a.height - args.shape
                x0 = x if x + args.shape <= a.width else a.width - args.shape
                result[(y0, x0)] = []
        num_objects = len(a.objects)
        object_num_step = len(a.objects) // args.num_workers
        for i in range(args.num_workers):
            right = (i + 1) * object_num_step
            pool.apply_async(process, (queue, result.keys(),
                                       a.height, a.width, args.shape, args.shape, slice_dy, slice_dx,
                                       a.objects[i * object_num_step:right if right <= num_objects else num_objects]))
        pool.close()
        pool.join()
        results = []
        for i in range(args.num_workers):
            results.append(queue.get())
        for k in result.keys():
            for i in range(args.num_workers):
                result[k] += results[i][k]
        image = cv2.imread(str(src_img_path / f"{file_name}.jpg"))
        for k in result:
            if len(result[k]) != 0:
                _y, _x = k
                new_image_path = dst_img_path / f"{file_name}_{_y}_{_x}.jpg"
                new_a = Annotation(str(new_image_path), args.shape, args.shape, 3)
                new_a.objects = result[k]
                if new_a.to_xml(str(dst_label_path / f"{new_image_path.stem}.xml")) is not None:
                    cv2.imwrite(str(new_image_path), image[_y:_y + args.shape, _x:_x + args.shape])
