from typing import List, Optional
from pathlib import Path
from functools import reduce
from ..models import Object
from ..tools import container_has_none
import xml.dom.minidom as DOC

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

WHOLE = "<annotation>{}</annotation>"
HEAD = "<folder>{}</folder><filename>{}</filename><path>{}</path><source><database>{\
}</database></source><size><width>{}</width><height>{}</height><depth>{}</depth></size><segmented>{}</segmented>"


class Annotation(object):
    def __init__(self,
                 path: str,
                 height: int,
                 width: int,
                 depth: int,
                 database: str = "Unknown",
                 segmented: int = 0):
        self.path = path
        self.width = width
        self.height = height
        self.depth = depth
        self.database = database
        self.segmented = segmented
        self.objects: List[Object] = []

    @classmethod
    def from_xml(cls, xml_path: str):
        tree = ET.ElementTree(file=xml_path)
        tree_root = tree.getroot()

        found_path = tree_root.find("path")
        if found_path is None:
            return None
        annotation_path = found_path.text

        found_source = tree_root.find("source")
        if found_source is None:
            return None
        found_database = found_source.find("database")
        if found_database is None:
            return None
        annotation_database = found_database.text

        found_segmented = tree_root.find("segmented")
        if found_segmented is None:
            return None
        annotation_segmented = int(found_segmented.text)

        found_size = tree_root.find("size")
        if found_size is None:
            return None
        found_sizes = list(
            map(lambda x: found_size.find(x), ["width", "height", "depth"]))
        if container_has_none(found_sizes):
            return None
        annotation_height, annotation_width, annotation_depth = tuple(
            map(lambda x: int(x.text), found_sizes))
        a = cls(annotation_path, annotation_height, annotation_width,
                annotation_depth, annotation_database, annotation_segmented)

        found_objects = tree_root.findall("object")
        for found_object in found_objects:
            a.objects.append(Object.from_xml_node(found_object))

        return a

    def to_xml(self, xml_path: str) -> Optional[str]:
        if xml_path == "":
            raise RuntimeError("The annotation file path must be specified.")
        objects_cleaned = [x for x in self.objects if x.valid()]
        if len(objects_cleaned) == 0:
            return None
        _xml_path = Path(xml_path).absolute()
        if _xml_path.exists():
            _xml_path.unlink()
        _xml_parent_name = _xml_path.parent.name
        _head = HEAD.format(_xml_parent_name, _xml_path.name, str(_xml_path),
                            self.database, self.width, self.height, self.depth,
                            self.segmented)
        _objects: str = reduce(lambda x, y: x + y,
                               [z.to_xml_str() for z in objects_cleaned])
        _whole = WHOLE.format(_head + _objects)
        xml_write = DOC.parseString(_whole)
        with _xml_path.open("w") as f:
            xml_write.writexml(f, '', ' ' * 4, '\n', encoding='utf-8')
        return _whole
