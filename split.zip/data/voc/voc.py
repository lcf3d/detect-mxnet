from pathlib import Path
from typing import Union


def mkdir_voc_or_clean(root_dir: Union[str, Path]) -> None:
    if (not isinstance(root_dir, str)) and (not isinstance(root_dir, Path)):
        raise TypeError("root_dir should be a string or a pathlib.Path.")
    root_dir_path = Path(root_dir) if isinstance(root_dir, str) else root_dir
    _paths = list(
        map(lambda x: root_dir_path / x,
            ["JPEGImages", "Annotations",
             Path("ImageSets", "Main")]))
    for _path in _paths:
        _path.mkdir(parents=True, exist_ok=True)
    annotation_path, label_path, index_path = tuple(_paths)
    for item in annotation_path.glob("*"):
        item.unlink()
    for item in label_path.glob("*"):
        item.unlink()
    for item in index_path.glob("*"):
        item.unlink()
