from typing import Iterable


def container_has_none(_container: Iterable):
    has = False
    for element in _container:
        if element is None:
            has = True
            break
    return has
