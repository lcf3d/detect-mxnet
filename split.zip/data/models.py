from .tools import container_has_none

try:
    import xml.etree.cElementTree as ET
except ImportError:
    import xml.etree.ElementTree as ET

OBJECT = "<object><name>{}</name><pose>{}</pose><truncated>{}</truncated><difficult>{}</difficult><bndbox><xmin>{\
}</xmin><ymin>{}</ymin><xmax>{}</xmax><ymax>{}</ymax></bndbox></object>"


class Object(object):
    def __init__(self, name: str, x_min: int, y_min: int, x_max: int, y_max: int,
                 pose: str = "Unspecified", truncated: int = 0, difficult: int = 0):
        self.name: str = name
        self.x_min: int = x_min
        self.y_min: int = y_min
        self.x_max: int = x_max
        self.y_max: int = y_max
        self.pose: str = pose
        self.truncated: int = truncated
        self.difficult: int = difficult

    @classmethod
    def from_xml_node(cls, xml_node: ET.Element):
        found = list(map(lambda x: xml_node.find(x), ["name", "pose", "truncated", "difficult", "bndbox"]))
        if container_has_none(found):
            return None
        obj_name, obj_pose = tuple(map(lambda x: x.text, found[:2]))
        obj_truncated, obj_difficult = tuple(map(lambda x: int(x.text), found[2:4]))
        found_box = list(map(lambda x: found[4].find(x), ["xmin", "ymin", "xmax", "ymax"]))
        if container_has_none(found_box):
            return None
        obj_x_min, obj_y_min, obj_x_max, obj_y_max = tuple(map(lambda x: int(x.text) - 1, found_box))
        return cls(obj_name, obj_x_min, obj_y_min, obj_x_max, obj_y_max, obj_pose, obj_truncated, obj_difficult)

    def valid(self) -> bool:
        if self.x_min < 0 or self.y_min < 0:
            return False
        if self.x_min >= self.x_max or self.y_min >= self.y_max:
            return False
        ratio = (self.x_max - self.x_min) / (self.y_max - self.y_min)
        if ratio < 0.1 or ratio > 10.0:
            return False
        return True

    def to_xml_str(self) -> str:
        return OBJECT.format(self.name, self.pose, self.truncated, self.difficult,
                             self.x_min + 1, self.y_min + 1, self.x_max + 1, self.y_max + 1)
